#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <time.h>

void main(int argc, char ** argv)
{
	int M1L = 5000, M1C = 5000, M2L = 5000, M2C = 5000;

	// c�digo de multiplica��o de matrizes modificado de http://homepages.dcc.ufmg.br/~rodolfo/aedsi-2-10/Arranjo/multiplica-matrizes.html
	int linha;
	int coluna;
	int i;
	int somaprod;
	// OPTIMIZA��O 1: Transformar arrays de 2D em 1D
	int * mat1 = NULL;
	int * mat2 = NULL;
	int * mat3 = NULL;
	time_t init_time, end_time;

	mat1 = (int *)malloc(M1L*M1C*sizeof(int));
	mat2 = (int *)malloc(M2L*M2C*sizeof(int));
	mat3 = (int *)malloc(M1L*M1C*sizeof(int));

	srand((unsigned int) time(NULL));

	printf("Inicializando matrizes...\n");
	for (int i = 0; i < M1L*M1C; i++) {
		mat1[i] = rand();
		mat2[i] = rand();
	}

	if (mat1 == NULL) {
		printf("ERRO: mat1 == NULL\n");
		return;
	}
	
	if (mat2 == NULL) {
		printf("ERRO: mat2 == NULL\n");
		return;
	}

	if (mat3 == NULL) {
		printf("ERRO: mat3 == NULL\n");
		return;
	}

	printf("Multiplicando matrizes... (opt 1)\n");	

	init_time = time(NULL);
	for (linha = 0; linha < M1L; linha++) {
		for (coluna = 0; coluna<M2C; coluna++) {
			somaprod = 0;
			for (i = 0; i < M1L; i++) {
				somaprod += mat1[(linha*M1C)+i] * mat2[(i*M2C)+coluna];
			}
			mat3[(linha*M1C)+coluna] = somaprod;
		}
		printf("\rprogress: %03d/%03d", linha, M1L);
	}

	time(&end_time);
	printf("\nTempo percorrido: %.f\n segundos\n",
		difftime(end_time, init_time));
	
#if 0
	// 
	//imprime mat3 
	// 
	for (linha = 0; linha<M1L; linha++){
		for (coluna = 0; coluna<M2C; coluna++)
			printf("%d ", mat3[linha+coluna]);
		printf("\n");
	}
#endif

	getchar();
}