#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void main(int argc, char ** argv)
{
	int M1L = 5000, M1C = 5000, M2L = 5000, M2C = 5000;

	// c�digo de multiplica��o de matrizes modificado de http://homepages.dcc.ufmg.br/~rodolfo/aedsi-2-10/Arranjo/multiplica-matrizes.html
	int linha;
	int coluna;
	int i;
	int somaprod;
	int ** mat1 = NULL;
	int ** mat2 = NULL;
	int ** mat3 = NULL;
	time_t init_time, end_time;

	srand((unsigned int)time(NULL));

	printf("Inicializando matrizes...\n");
	mat1 = (int **)malloc(M1L*sizeof(int*));
	for (i = 0; i < M1L; i++){
		mat1[i] = (int *)malloc(M1C*sizeof(int));
		for (int j = 0; j < M1C; j++) {
			mat1[i][j] = rand();
		}
	}
	mat2 = (int **)malloc(M2L*sizeof(int*));
	for (i = 0; i < M2L; i++){
		mat2[i] = (int *)malloc(M2C*sizeof(int));
		for (int j = 0; j < M2C; j++) {
			mat2[i][j] = rand();
		}
	}
	mat3 = (int **)malloc(M1L*sizeof(int*));
	for (i = 0; i < M1L; i++){
		mat3[i] = (int *)malloc(M1C*sizeof(int));
	}	

	if (mat1 == NULL) {
		printf("ERRO: mat1 == NULL\n");
		return;
	}
	
	if (mat2 == NULL) {
		printf("ERRO: mat2 == NULL\n");
		return;
	}

	if (mat3 == NULL) {
		printf("ERRO: mat3 == NULL\n");
		return;
	}

	printf("Multiplicando matrizes...\n");

	init_time = time(NULL);
	for (linha = 0; linha < M1L; linha++) {
		for (coluna = 0; coluna<M2C; coluna++) {
			somaprod = 0;
			for (i = 0; i < M1L; i++) {
				somaprod += mat1[linha][i] * mat2[i][coluna];
			}
			mat3[linha][coluna] = somaprod;
		}
		printf("\rprogress: %03d/%03d", linha, M1L);
	}

	time(&end_time);
	printf("\nTempo percorrido: %.f\n segundos\n",
		difftime(end_time, init_time));
	
#if 0
	// 
	//imprime mat3 
	// 
	for (linha = 0; linha<M1L; linha++){
		for (coluna = 0; coluna<M2C; coluna++)
			printf("%d ", mat3[linha+coluna]);
		printf("\n");
	}
#endif

	getchar();
}